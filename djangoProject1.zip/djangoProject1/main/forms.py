from django import forms
from .models import Articles, Comments
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User


class ArticleForm(forms.ModelForm):
    class Meta:
        model = Articles
        fields = ('name', 'text')
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs['class'] = 'form-control'


class AuthUserForm(AuthenticationForm, forms.ModelForm):
    class Meta:
        model = User
        fields = ('username', 'password')
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['class'] = 'form-control mb-4'
        self.fields['username'].widget.attrs['placeholder'] = 'Login or email'
        self.fields['username'].label = ''
        self.fields['password'].widget.attrs['class'] = 'form-control mb-4'
        self.fields['password'].widget.attrs['placeholder'] = 'Password'
        self.fields['password'].widget.attrs['type'] = 'password'
        self.fields['password'].label = ''


class RegisterUserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('email', 'username', 'password')
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['email'].widget.attrs['class'] = 'form-control mb-4'
        self.fields['email'].widget.attrs['placeholder'] = 'Email'
        self.fields['email'].label = ''
        self.fields['username'].widget.attrs['class'] = 'form-control mb-4'
        self.fields['username'].widget.attrs['placeholder'] = 'Login'
        self.fields['username'].label = ''
        self.fields['username'].help_text = ''
        self.fields['password'].widget.attrs['class'] = 'form-control mb-4'
        self.fields['password'].widget.attrs['placeholder'] = 'Password'
        self.fields['password'].widget.attrs['type'] = 'password'
        self.fields['password'].label = ''
    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comments
        fields = ('text',)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['text'].widget.attrs['class'] = 'form-control mb-4'
        self.fields['text'].widget.attrs['placeholder'] = 'Write your comment here...'
        self.fields['text'].widget.attrs['style'] = 'height:100px;'
        self.fields['text'].label = ''
