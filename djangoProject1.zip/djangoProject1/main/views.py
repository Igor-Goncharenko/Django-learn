from django.contrib import  messages
from django.shortcuts import render, redirect
from .models import Articles
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.views.generic.edit import FormMixin
from django.contrib.auth.views import LoginView, LogoutView
from .forms import ArticleForm, AuthUserForm, RegisterUserForm, CommentForm
from django.urls import reverse, reverse_lazy
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect


class CustomSuccessMessageMixin:
    """Message alert class"""
    @property
    def success_msg(self):
        return False

    def form_valid(self, form):
        messages.success(self.request, self.success_msg)
        return super().form_valid(form)

    def get_success_url(self):
        return '%s?id=%s' % (self.success_url, self.object.id)


def home(request):
    context = {

    }
    template = 'main/home_page.html'
    return render(request, template, context)


class BlogListView(ListView):
    """Blog page class"""
    model = Articles
    template_name = 'main/blog_page.html'
    def get_context_data(self, **kwargs):
        kwargs['list_articles'] = Articles.objects.all().order_by("-id")
        return super().get_context_data(**kwargs)


class BlogDetailView(FormMixin, DetailView):
    """Detail page class"""
    model = Articles
    template_name = 'main/detail_page.html'
    #context_object_name = 'get_article'
    form_class = CommentForm
    def get_context_data(self, **kwargs):
        kwargs['get_article'] = Articles.objects.get(id=self.object.id)
        kwargs['comments'] = Articles.objects.get(id=self.object.id).comments_articles.order_by("-id")
        return super().get_context_data(**kwargs)
    def get_success_url(self, **kwargs):
        return reverse_lazy('detail', kwargs={'pk':self.get_object().id})
    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)
    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.article = self.get_object()
        self.object.author = self.request.user
        self.object.save()
        return super().form_valid(form)


def pricing(request):
    context = {

    }
    template = 'main/pricing_page.html'
    return render(request, template, context)


class ArticleCreateView(LoginRequiredMixin, CustomSuccessMessageMixin, CreateView):
    """Article create class"""
    model = Articles
    template_name = 'main/edit_page.html'
    form_class = ArticleForm
    success_url = reverse_lazy('edit')
    success_msg = "Successfully added"
    login_url = '/login/'
    def get_context_data(self, **kwargs):
        kwargs['list_articles'] = Articles.objects.all().order_by("-id")
        my_articles = [a for a in Articles.objects.all() if a.author == self.request.user]
        kwargs['my_articles'] = my_articles
        return super().get_context_data(**kwargs)
    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.author = self.request.user
        self.object.save()
        return super().form_valid(form)


class ArticleUpdateView(LoginRequiredMixin, CustomSuccessMessageMixin, UpdateView):
    """Article edit class"""
    model = Articles
    template_name = 'main/edit_page.html'
    form_class = ArticleForm
    success_url = reverse_lazy('edit')
    success_msg = "Successfully changed"
    login_url = '/login/'
    def get_context_data(self, **kwargs):
        kwargs['updatePageOpened'] = True
        return super().get_context_data(**kwargs)
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        if self.request.user != kwargs['instance'].author:
            return self.handle_no_permission()
        return kwargs


class ArticleDeleteView(LoginRequiredMixin, CustomSuccessMessageMixin, DeleteView):
    """Article delete class"""
    model = Articles
    template_name = 'main/edit_page.html'
    success_url = reverse_lazy('edit')
    success_msg = "Successfully deleted"
    login_url = '/login/'
    def post(self, request, *args, **kwargs):
        messages.success(self.request, self.success_msg)
        return super().post(request)
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        if self.request.user != self.object.author:
            return self.handle_no_permission()
        success_url = self.get_success_url()
        self.object.delete()
        return HttpResponseRedirect(success_url)


class AccountLoginView(LoginView):
    """Login class"""
    template_name = 'main/login_page.html'
    form_class = AuthUserForm
    success_url = reverse_lazy('edit')
    def get_success_url(self):
        return self.success_url


class AccountRegisterView(CreateView):
    """Register class"""
    model = User
    template_name = 'main/register_page.html'
    form_class = RegisterUserForm
    success_url = reverse_lazy('edit')

    def form_valid(self, form):
        form_valid = super().form_valid(form)
        username = form.cleaned_data["username"]
        password = form.cleaned_data["password"]
        auth_user = authenticate(username=username, password=password)
        login(self.request, auth_user)
        return form_valid


class AccountLogoutView(LogoutView):
    """Logout class"""
    def get_next_page(self):
        next_page = self.request.META.get('HTTP_REFERER')
        return next_page