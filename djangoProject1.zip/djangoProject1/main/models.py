from django.db import models
from django.contrib.auth.models import User


class Articles(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Author")
    create_date = models.DateTimeField(auto_now=True, verbose_name="Date")
    name = models.CharField(max_length=200, verbose_name="Title")
    text = models.TextField(verbose_name="Descrition")

    def __str__(self):
        #'%s: %s-%s' % (self.create_date, self.name, self.text)
        return self.name

    class Meta:
        verbose_name = "Article"
        verbose_name_plural = "Articles"


class Comments(models.Model):
    article = models.ForeignKey(Articles, on_delete=models.CASCADE, verbose_name="Article", related_name='comments_articles')
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Author")
    create_date = models.DateTimeField(auto_now=True, verbose_name="Date")
    text = models.TextField(verbose_name="Text")
    status = models.BooleanField(verbose_name="Visibility", default=False)