from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('blog/', views.BlogListView.as_view()  , name="blog"),
    path('detail/<int:pk>', views.BlogDetailView.as_view(), name="detail"),
    path('pricing/', views.pricing, name="pricing"),
    path('login/', views.AccountLoginView.as_view(), name="login"),
    path('register/', views.AccountRegisterView.as_view(), name="register"),
    path('logout/', views.AccountLogoutView.as_view(), name="logout"),
    path('edit/', views.ArticleCreateView.as_view(), name="edit"),
    path('update/<int:pk>', views.ArticleUpdateView.as_view(), name="update"),
    path('delete_page/<int:pk>', views.ArticleDeleteView.as_view(), name="delete_page"),
]
